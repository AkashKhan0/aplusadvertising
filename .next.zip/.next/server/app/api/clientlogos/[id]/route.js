var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/clientlogos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__a969ea86._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(40148)
R.m(40468)
module.exports=R.m(40468).exports
