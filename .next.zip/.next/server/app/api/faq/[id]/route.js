var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/faq/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__daa63c62._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_48b9435f._.js")
R.m(87547)
R.m(2868)
module.exports=R.m(2868).exports
