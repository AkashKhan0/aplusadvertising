var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/categories/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__5fe7f771._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(63968)
R.m(44989)
module.exports=R.m(44989).exports
