var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/plan/route.js")
R.c("server/chunks/[root-of-the-server]__9b9d8a17._.js")
R.c("server/chunks/node_modules_next_48b9435f._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__f0dbb446._.js")
R.m(97730)
R.m(6007)
module.exports=R.m(6007).exports
