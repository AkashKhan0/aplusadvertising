var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ordertemplate/route.js")
R.c("server/chunks/[root-of-the-server]__648425de._.js")
R.c("server/chunks/node_modules_next_48b9435f._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/[root-of-the-server]__f0dbb446._.js")
R.m(39149)
R.m(3364)
module.exports=R.m(3364).exports
