var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orderplan/route.js")
R.c("server/chunks/[root-of-the-server]__9c726201._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(99348)
R.m(47448)
module.exports=R.m(47448).exports
