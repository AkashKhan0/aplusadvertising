var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sendMail/route.js")
R.c("server/chunks/[root-of-the-server]__5f8f3f07._.js")
R.c("server/chunks/[root-of-the-server]__f0dbb446._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.m(26347)
R.m(72241)
module.exports=R.m(72241).exports
